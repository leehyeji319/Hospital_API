package com.merakiplace.test.domain;

/**
 *packageName    : com.merakiplace.test.domain
 * fileName       : Days
 * author         : modsiw
 * date           : 2023/05/20
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2023/05/20        modsiw       최초 생성
 */


public enum Days {
	MON,
	TUE,
	WED,
	THU,
	FRI,
	SAT,
	SUN
}
